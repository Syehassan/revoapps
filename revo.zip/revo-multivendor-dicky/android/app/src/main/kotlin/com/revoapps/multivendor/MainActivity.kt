package com.revoapps.multivendor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
