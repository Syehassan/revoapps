import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdMobConstant {
  /*DISCLAIMER : make sure you have already know how to use and create an Ad Mob account.*/

  /*Set TRUE if using AdMob*/
  static const bool isAdMobActive = true;

  /* Ad Unit can be set the same or different for each variable. Make sure ad unit type for each platforms (Android & iOS) is BANNER AD.
  if you just want to set for android (Android deployment only) you can set blank/empty value the IOS variable,
  but if you want to upload both platforms then you must fill all variable */
  static const String adUnitHomeAndroid =
      "ca-app-pub-1564903178335301/2114821351";
  static const String adUnitCategoryAndroid =
      "ca-app-pub-1564903178335301/3591554550";
  static const String adUnitProductAndroid =
      "ca-app-pub-1564903178335301/5499516686";

  static const String adUnitHomeIOS = "ca-app-pub-3782898631209093/2704643014";
  static const String adUnitCategoryIOS =
      "ca-app-pub-3782898631209093/2704643014";
  static const String adUnitProductIOS =
      "ca-app-pub-3782898631209093/2704643014";

  /* you can also resize the banner ad */
  static const AdSize adSizeBanner = AdSize.mediumRectangle;

  static void initAdMob() {
    if (isAdMobActive) {
      MobileAds.instance.initialize();
    }
  }
}
