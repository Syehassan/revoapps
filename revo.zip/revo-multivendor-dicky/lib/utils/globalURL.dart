import 'package:revo_multivendor/services/multivendor_base_api.dart';

// baseurl
String url = "https://demomarketplace.revoapps.id";

// oauth_consumer_key
String consumerKey = "ck_7e9a22dd7a539e637d57abce45264027bf759fa8";
String consumerSecret = "cs_21e36f414d511798bdd8d985308a3fc9efc16a0e";

// baseApiRequest for Multivendor
MultiVendorBaseAPI baseAPI =
    MultiVendorBaseAPI(url, consumerKey, consumerSecret);

// General Settings Endpoint
String introPage = 'home-api/intro-page';
String generalSetting = 'home-api/general-settings';

// Register Endpoint
String signUpUrl = 'register';

// Auth Endpoint
String loginDefault = 'generate_auth_cookie';
String signInOTP = 'firebase_sms_login';
String sendEmailForgot = 'send-email-forgot-password';
String checkPasswordKey = 'check-password-reset-key';
String resetPassword = 'reset-password';

// Home Endpoint
String homeSlider = 'home-api/slider';
String homeCategory = 'home-api/categories';
String homeMiniBanner = 'home-api/mini-banner';
String extendProducts = 'home-api/extend-products';
String recentProducts = 'home-api/recent-view-products';
String newHomeURL = 'home-api';

// Product Endpoint
String product = 'list-produk';
String attribute = 'wc-attributes-term';
String checkWishlistProduct = 'home-api/check-product-wistlist';
String setWishlistProduct = 'home-api/add-remove-wistlist';
String listWishlistProduct = 'home-api/list-product-wistlist';
String checkVariations = 'home-api/check-produk-variation';
String reviewProductUrl = '$product/reviews';
String getBarcodeUrl = 'get-barcode';
String getFlashSaleURL = 'home-api/flash-sale';
String addReviewUrl = 'products/reviews';
String hitViewedProducts = 'home-api/hit-products';

// Categories
String productCategories = 'products/categories';
String allCategoriesURL = 'get-all-categories';

// Store Endpoint
String allStoreUrl = 'get-vendor-list';
String detailStoreUrl = 'get-vendor-detail';
String uploadImgUrl = 'upload-image';
String inputProductUrl = 'input-produk';
String removeProductUrl = 'delete-produk';
String openCloseStoreURL = 'vendor-submit-open-close-store';

//Attribute Variant Product Endpoint
String attributeUrl = 'wc-attributes-term';

// Vendor
String createUpdateVendorURL = 'create-update-vendor';
String rekeningVendorURL = 'update-payment-vendor';
String vendorRequestListURL = 'vendor-request-withdrawal';
String vendorListHistoryURL = 'vendor-get-history-withdrawal';
String vendorSubmitRequestURL = 'vendor-submit-request-withdrawal';

// Profile Endpoint
String detailProfileUrl = 'get_currentuserinfo';
String updateProfileUrl = 'update_user_profile';

// Order
String orderApi = '/revo-checkout/';
String listOrders = 'home-api/list-orders';
String listOrdersVendorUrl = 'get-orders-vendor-list-new';
String updateOrderUrl = 'update-status-order-new';

//Notification
String listNotificationURL = 'home-api/list-notification';
String pushNotificationURL = 'home-api/input-token-firebase';

//Chat
String detailChatURL = 'detail-chat';
String listChatURL = 'list-user-chat';
String insertChatURL = 'insert-chat';

//Shipping
String getEpekenSettingURL = 'vendor-get-shipping-setting';
String submitEpekenKurir = 'vendor-submit-shipping-setting';
String wcShippingSetting = 'wc-shipping-settings';
String wcShippingDetail = 'wc-detail-shipping';
String wcPostShipping = 'wc-addOrRemove-shipping-method';
String wcPostShippingSetting = 'wc-update-shipping-settings';
String wcPostShippingDetail = 'wc-update-shipping-zone-postalcode';
String wcUpdateShippingMethod = 'wc-update-shipping-method';

//Blog
String blogListURL = 'posts';
String listCommentURL = 'comments';
String sendCommentURL = 'post_comment/';

//Coupon
String coupon = 'coupons';
String applyCoupon = 'apply-coupon';
String listCoupon = 'list-coupons';

// Wallet
String topUpWalletUrl = 'topup-woowallet';
String transferWalletUrl = 'transfer-woowallet';
String transactionWalletUrl = 'wallet';
String balanceWalletUrl = 'wallet/balance';
